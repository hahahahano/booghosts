/*globals Phaser*/
//import * as ChangeScene from './ChangeScenes.js';
export default class Scene5 extends Phaser.Scene {
  constructor () {
    super('Scene5');
  }

  preload() {
    this.load.image("sky", "./assets/images/background.png",{
      frameWidth: 432,
      frameHeight: 32,
    });
    this.load.image("ground", "./assets/cave1.png");
    this.load.image("star", "./assets/sprites/mem.png");
    this.load.spritesheet("dude", "./assets/Ghost2.png", {
      frameWidth: 462,
      frameHeight: 719
    });
  }

  create() {
    //Add change scene event listeners
    //ChangeScene.addSceneEventListeners(this);

    this.player;
    this.stars;
    var platforms;
    this.cursors;
    this.score = 0;
    this.gameOver = false;
    this.scoreText;

    //  A simple background for our game
    this.add.image(1280/2, 960/2, "sky");

    //  The platforms group contains the ground and the 2 ledges we can jump on
    platforms = this.physics.add.staticGroup();

    //  Here we create the ground.
    //  Scale it to fit the width of the game (the original sprite is 400x32 in size)
    platforms
      .create(400,750 , "ground")
      .setScale(1)
      .refreshBody();

    //  Now let's create some ledges
    //platforms
      //.create(200, 400, "ground")
    //  .setScale(.2)
    //  .refreshBody();
    //platforms.create(0,300, "ground");
    //platforms.create(750, 350, "ground");
    platforms
      .create(600, 200, "ground")
      .setScale(.2)
      .refreshBody();


    // The player and its settings
    this.player = this.physics.add.sprite(100, 450, "dude");
    this.player.setScale(.2);

    //  Player physics properties. Give the little guy a slight bounce.
    this.player.setBounce(0.2);
    this.player.setCollideWorldBounds(true);

    //Set gravity of this scene
    this.physics.world.gravity.y = 300;

    //  Our player animations, turning, walking left and walking right.
    //create animation from spriteSheets
    this.anims.create({
      key: 'walk',
      frames: this.anims.generateFrameNumbers('dude', {start: 0, end: 0}),
      framerate: 10,
      repeat: -1

    });
    this.anims.create({
      key: 'idle',
      frames: this.anims.generateFrameNumbers('dude', {start: 0, end: 0}),
      framerate: 10,
      repeat: -1
    });

    //  Input Events
    this.cursors = this.input.keyboard.createCursorKeys();

    //  Some stars to collect, 12 in total, evenly spaced 70 pixels apart along the x axis
    this.stars = this.physics.add.group({
      key: "star",
      repeat: 11,
      setXY: { x: 12, y: 0, stepX: 70 }
    });


    this.stars.children.iterate(function(child) {
      //  Give each star a slightly different bounce
      child.setBounce(Phaser.Math.FloatBetween(0.4, 0.8));
    });







    //  The score
    this.scoreText = this.add.text(16, 16, "score: 0", {
      fontSize: "32px",
      fill: "#000"
    });

    //  Collide the player and the stars with the platforms
    this.physics.add.collider(this.player, platforms);
    this.physics.add.collider(this.stars, platforms);

    //  Checks to see if the player overlaps with any of the stars, if he does call the collectStar function
    this.physics.add.overlap(
      this.player,
      this.stars,
      this.collectStar,
      null,
      this
    );

    this.physics.add.collider(
      this.player,
      this.bombs,
      null,
      this
    );
  }

  update() {
    if (this.gameOver) {
      this.scene.start('GameOverScene',{score: this.score });
      return;
    }

    var cursors = this.input.keyboard.createCursorKeys();
    var speed = 5;

    if (cursors.left.isDown) {
      this.player.setVelocityX(-160);
      this.player.flipX = true;
      this.player.anims.play('walk', true);
    } else if (cursors.right.isDown){
      this.player.setVelocityX(160);
      this.player.flipX = false;
      this.player.anims.play('walk', true);
    }else {
      this.player.setVelocityX(0);
      this.player.anims.play('idle', true);
    }
    if (cursors.up.isDown ) {
      this.player.setVelocityY(-330);
    } else if (cursors.down.isDown){
      this.player.setVelocityY(500);
    }
  }

  collectStar(player, star) {
    star.disableBody(true, true);

    //  Add and update the score
    this.score += 10;
    this.scoreText.setText("Score: " + this.score);

    if (this.stars.countActive(true) === 0) {
      //  A new batch of stars to collect
      this.gameOver = true
      };


  }

}
