/*global Phaser, window*/
import GameOverScene from './scenes/GameOverScene.js';

import Scene3 from './scenes/Scene3.js';
import Scene5 from './scenes/Scene5.js';
import Config from './config/config.js';

class Game extends Phaser.Game {
  constructor () {
    super(Config);

    this.scene.add('GameOverScene', GameOverScene);
    this.scene.add('Scene3',Scene3);
    this.scene.add('Scene5',Scene5);
    this.scene.start('Scene3');
  }
}

window.game = new Game();
